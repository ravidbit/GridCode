import React from 'react';

export const tabgrid = (props) => <h4>{props.person.name}</h4>
