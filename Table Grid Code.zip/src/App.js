import React, { Component } from 'react';
// import Home from './Home';
 //import tsgrid from './gridview';
class App extends Component {
  constructor(){
    super();
    // this.state = {items : []}
  //  this.state = {items : []}
    this.state = {data : [] } 
  }


  
componentWillMount(){
//fetch('http://api.worldbank.org/v2/countries?format=json')
// fetch('https://swapi.co/api/people/?format=json')
// .then(response => response.json())
// .then(({results:items}) => this.setState({items}))
// .catch(e => console.log(e))




fetch('http://api.worldbank.org/v2/countries?format=json')
.then(response => response.json())
.then(response => this.setState({ data: response }))
.catch(err => console.log(err))


}

  render() 
  {
   // let items = this.state.items
    let data = this.state.data
    var arr = [];
    Object.keys(data).forEach(function(key) {
      arr.push(data[key][0]);
    });

    console.log(arr)

    return (
      <div>
       
         {/* {items.map(item => 
          //<h4>{item.name}</h4>)
         <Namegrid key={item.name} person={item} /> 
         )} */}
    {

      //data.map(item => <div key={item.id}>{item.name}</div>)
      //data.map(item => console.log(item.name))
      
      data.map( (arr,i) => console.log(arr[i]))

     // data.map( (dt,i) => console.log(dt[i]))
      // data.map(i => console.log(i.map(
      //   j => console.log(j['id'])
      // )))
    }


      {
        //data.map( (dt , index) => 
         //console.log(dt[index])
         
        //<div>{data.id} : {data.name}</div>
         //<p key={dt[index]}>{dt.name}</p>
         //<Namegrid key={dt[index].id} nmgrid={dt[index].name} /> 
        // dt[index].map(
        //   (data) => 
        //     <h1>{data.id}</h1>
        //    )
         
        // )
        }

      </div>
    );
  }
}


//const Namegrid = (props) => <h4 >{props.nmgrid.name}</h4>


export default App;