import React, { Component } from 'react';
import './App.css';

import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';

class App1 extends Component {
    constructor(props) {
        super(props);

        // this.state = {
        //     columnDefs: [
        //         {headerName: 'Make', field: 'make'},
        //         {headerName: 'Model', field: 'model'},
        //         {headerName: 'Price', field: 'price'}

        //     ],
        //     rowData: [
        //         {make: 'Toyota', model: 'Celica', price: 35000},
        //         {make: 'Ford', model: 'Mondeo', price: 32000},
        //         {make: 'Porsche', model: 'Boxter', price: 72000}
        //     ]
        // }


        this.state = {
          columnDefs: [
            {headerName: 'Iso2Code'    , field : 'iso2Code'},
            {headerName: 'Name'        , field : 'name'},
            {headerName: 'Region'      , field : 'region'},
            {headerName: 'Adminregion' , field : 'adminregion'},
            {headerName: 'IncomeLevel' , field : 'incomeLevel'},
            {headerName: 'LendingType' , field : 'lendingType'},
            {headerName: 'CapitalCity' , field : 'capitalCity'},
            {headerName: 'Longitude'   , field : 'longitude'},
            {headerName: 'Latitude'    , field : 'latitude'}

          ],
          rowData: [
              {
                iso2Code : '1',
                name : 'India',
                region : 'ASIA',
                adminregion : 'Test',
                incomeLevel : 'Test',
                lendingType : 'test',
                capitalCity : 'Test',
                longitude : 'Test',
                latitude : 'Test'
              }
              
          ]
      }

    }


    componentDidMount() {
     // fetch('https://api.myjson.com/bins/15psn9')
      fetch('http://api.worldbank.org/v2/countries?format=json')

          .then(result => result.json())
          .then(
             rowData => this.setState({rowData}
            ))
            .catch(e => console.log(e));
           // alert('hi');()
  }


    render() {
        return (
            <div
                className="ag-theme-balham"
                style={{ height: '200px', width: '600px' }}
            >
                <AgGridReact
                    pagination={true}
                    enableSorting={true}
                    enableFilter={true}
                    columnDefs={this.state.columnDefs}
                    rowData={this.state.rowData}>
                </AgGridReact>
            </div>
        );
    }
}

export default App1;




















//// ====================================================================================




// import React, { Component } from 'react';
// import Home from './Home';
// // import logo from './logo.svg';
// // import './App.css';

// class App extends Component {
//   render() {
//     return (
//       <div className="App">
//         {/* <header className="App-header">
//           <img src={logo} className="App-logo" alt="logo" />
//           <p>
//             Edit <code>src/App.js</code> and save to reload.
//           </p>
//           <a
//             className="App-link"
//             href="https://reactjs.org"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             Learn React
//           </a>
//         </header> */}
//           <a
//             className="App-link"
//             href="https://reactjs.org"
//             target="_blank"
//             rel="noopener noreferrer"
//           >
//             Learn React
//           </a>

//           <Home></Home>
         

//       </div>
//     );
//   }
// }

// export default App;






// // import React from 'react'
// // import { render } from 'react-dom'
// // import { Provider } from 'react-redux'
// // import { ConnectedRouter } from 'connected-react-router'
// // import store, { history } from './store'
// // import App from './containers/app'

// // import './index.css'

// // const target = document.querySelector('#root')

// // render(
// //   <Provider store={store}>
// //     <ConnectedRouter history={history}>
// //       <div>
// //         <App />
// //       </div>
// //     </ConnectedRouter>
// //   </Provider>,
// //   target
// // )